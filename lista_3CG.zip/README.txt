trabalho de computação grafica lista_3
alunos:
Adjailson Freire de Sá Filho ,matricula:20223002120
Lucas Andrade Brandão, matricula:20223002540
Gustavo De Assis Xavier, matricula:20223003379

Para executar o jogo digite no terminal dentro dessa pasta "make executar".
para somente executar o jogo "make compilar"

#Bibliotecas adicionais -freeglut -soil

para instalar a freeglut no linux digite no terminal "sudo apt-get install libglut3-dev"

para instalar a soil no linux digite no terminal "sudo apt-get install libsoil-dev"